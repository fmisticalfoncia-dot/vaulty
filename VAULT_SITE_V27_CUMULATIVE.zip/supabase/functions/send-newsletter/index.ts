import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return new Response(JSON.stringify({ error: 'POST only' }), { status: 405, headers: { ...cors, 'Content-Type': 'application/json' } });

  const adminToken = Deno.env.get('NEWSLETTER_ADMIN_TOKEN');
  const supplied = req.headers.get('authorization')?.replace(/^Bearer\s+/i, '');
  if (!adminToken || !supplied || supplied !== adminToken) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...cors, 'Content-Type': 'application/json' } });
  }

  const { subject, html } = await req.json().catch(() => ({}));
  if (!subject || !html) {
    return new Response(JSON.stringify({ error: 'subject and html are required' }), { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } });
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SECRET_KEY') || Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    { auth: { persistSession: false, autoRefreshToken: false } }
  );

  const { data: rows, error } = await supabase
    .from('newsletter_subscribers')
    .select('email')
    .order('created_at', { ascending: true });

  if (error) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...cors, 'Content-Type': 'application/json' } });
  }

  const resendKey = Deno.env.get('RESEND_API_KEY');
  const from = Deno.env.get('VAULT_FROM_EMAIL');
  if (!resendKey || !from) {
    return new Response(JSON.stringify({ error: 'RESEND_API_KEY and VAULT_FROM_EMAIL are required' }), { status: 500, headers: { ...cors, 'Content-Type': 'application/json' } });
  }

  let sent = 0;
  const failures: Array<{ email: string; message: string }> = [];

  for (const row of rows ?? []) {
    try {
      const r = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${resendKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from, to: [row.email], subject, html }),
      });
      if (!r.ok) {
        failures.push({ email: row.email, message: await r.text() });
      } else sent += 1;
    } catch (e) {
      failures.push({ email: row.email, message: e instanceof Error ? e.message : String(e) });
    }
  }

  return new Response(JSON.stringify({ ok: failures.length === 0, attempted: (rows ?? []).length, sent, failed: failures.length, failures }), {
    status: failures.length ? 207 : 200,
    headers: { ...cors, 'Content-Type': 'application/json' },
  });
});
